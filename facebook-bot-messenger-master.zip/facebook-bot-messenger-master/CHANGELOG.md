## v1.0.2
 - Add event `isQuickReply` to echo.event.js

## v1.0.3
 - Can change GraphAPI version
 - Fixed bug

## v1.0.4
 - Fixed bug

## v1.0.5
 - Fixed bug ListTemplateBuilder thx @mastasky

## v1.0.6
 - Fixed bug send duplicated response
 - Edited README.md

## v.1.0.7
 - Create method for parsing Facebook JSON string only (private)

## v.1.0.8
 - Add options request user phone number and user email in quick reply